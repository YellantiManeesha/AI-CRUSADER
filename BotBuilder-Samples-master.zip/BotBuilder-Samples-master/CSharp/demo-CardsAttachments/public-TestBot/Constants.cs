﻿namespace TestBot
{
    public static class Constants
    {
        public const string LastJsonKey = "LastJson";

        public const string LastCSharpKey = "LastCSharp";

        public const string LastNodeJsKey = "LastNodeJs";

        public const string JsonTrigger = "JSON";

        public const string CSharpTrigger = "C#";

        public const string NodeJsTrigger = "NODE";
    }
}