﻿namespace DirectLineSampleClient.Models
{
    public class DirectLineCardContent
    {
        public string Text { get; set; }

        public string Title { get; set; }
    }
}