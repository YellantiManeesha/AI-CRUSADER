﻿namespace ContosoFlowers.Services.Models
{
    using System;

    [Serializable]
    public class FlowerCategory
    {
        public string Name { get; set; }

        public string ImageUrl { get; set; }
    }
}
